%function pointCloudIndex = callbackClickA3DPoint(src, eventData, pointCloud,index)
%function pointCloudIndex = callbackClickA3DPoint(src, eventData, pointCloud, point_indexes, ind)

function pointCloudIndex = callbackClickA3DPoint(src, eventData, pointCloud)
% CALLBACKCLICK3DPOINT mouse click callback function for CLICKA3DPOINT
%
%   The transformation between the viewing frame and the point cloud frame
%   is calculated using the camera viewing direction and the 'up' vector.
%   Then, the point cloud is transformed into the viewing frame. Finally,
%   the z coordinate in this frame is ignored and the x and y coordinates
%   of all the points are compared with the mouse click location and the
%   closest point is selected.
%
%   Babak Taati - May 4, 2005
%   revised Oct 31, 2007
%   revised Jun 3, 2008
%   revised May 19, 2009

point = get(gca, 'CurrentPoint'); % mouse click position
camPos = get(gca, 'CameraPosition'); % camera position
camTgt = get(gca, 'CameraTarget'); % where the camera is pointing to

camDir = camPos - camTgt; % camera direction
camUpVect = get(gca, 'CameraUpVector'); % camera 'up' vector

% build an orthonormal frame based on the viewing direction and the
% up vector (the "view frame")
zAxis = camDir/norm(camDir);
upAxis = camUpVect/norm(camUpVect);
xAxis = cross(upAxis, zAxis);
yAxis = cross(zAxis, xAxis);

rot = [xAxis; yAxis; zAxis]; % view rotation

% the point cloud represented in the view frame
rotatedPointCloud = rot * pointCloud;

% the clicked point represented in the view frame
rotatedPointFront = rot * point' ;

% find the nearest neighbour to the clicked point
pointCloudIndex = dsearchn(rotatedPointCloud(1:2,:)', ...
    rotatedPointFront(1:2));

h = findobj(gca,'Tag','pt'); % try to find the old point
selectedPoint = pointCloud(:, pointCloudIndex);

% controllo indici

% if ismember(pointCloudIndex, point_indexes) % pointCloudIndex è già presente nell'array degli indici
%     disp("Non salvo l'indice"); 
% else
%     disp("Salvo l'indice"); 
%     point_indexes = [point_indexes, pointCloudIndex]; 
%     ind = ind + 1;
% end
% fprintf("Point_indexes: %d \n", point_indexes); 

if isempty(h) % if it's the first click (i.e. no previous point to delete)
   
    % highlight the selected point
    h = plot3(selectedPoint(1,:), selectedPoint(2,:), ...
        selectedPoint(3,:), 'r.', 'MarkerSize', 20);
    set(h,'Tag','pt'); % set its Tag property for later use
    
else % if it is not the first click
    
    delete(h); % delete the previously selected point
   
    % highlight the newly selected point
    h = plot3(selectedPoint(1,:), selectedPoint(2,:), ...
        selectedPoint(3,:), 'r.', 'MarkerSize', 20);
    set(h,'Tag','pt');  % set its Tag property for later use
    
end


fprintf('Point index %d\n', pointCloudIndex);

% Save indexes - li filtro dopo 
% s = struct('Point_indexes', point_indexes);
% t = jsonencode(s); 
% [tp] = prettyjson(t); 
% 
% fid = fopen('bo.json','a+'); % append
% fprintf(fid,'%s\n', tp);  
% fclose(fid);


% points = evalin('caller','points');
% points = [points pointCloudIndex];
% assignin('caller','points',points);


