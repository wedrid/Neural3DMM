clear all; close all; clc; 
% dirname = '.\subject001\single_frame_off\';
dirname = '.\face_frames\';
doicp = true;

files = dir( [dirname '*_crop.mat'] );
nfiles = size(files,1);

% read the .mat file with the point set of the first face (reference)
name = files(1).name;
load( [dirname name], 'vertex' );
% center the frame
vertex = vertex - repmat(mean(vertex,2),1,size(vertex,2));
% plot currently read frame
figure 
hold on
plot3(vertex(1,:),vertex(2,:),vertex(3,:),'k.');
view(0,90);
title('first frame')
hold off

% plot the reference frame as mesh (Delaunay triangulation)
faces = delaunay(vertex(1,:),vertex(2,:));
figure('Name', ['reference mesh surface' num2str(i)])
plot_mesh(vertex,faces);

cum_point_cloud = vertex;
for i = 2 : 10
    % read the .mat file with the point set of the face 
    name = files(i).name;
    vertex = [];
    load( [dirname name], 'vertex' );
    vertex = vertex - repmat(mean(vertex,2),1,size(vertex,2));
    if doicp
        % ICP 
        [TR, TT, ER] = icp( cum_point_cloud, vertex, 60, 'Matching', 'kDtree', 'Minimize', 'plane', 'WorstRejection', 0.2 );
%         [TR, TT, ER] = icp( cum_point_cloud, vertex, 60, 'Matching', 'kDtree', 'WorstRejection', 0.2 );
        vertex_icp = TR * vertex + repmat(TT, 1, size(vertex,2)); 
        % plot currently read frame
        figure
        hold on
        plot3(cum_point_cloud(1,:),cum_point_cloud(2,:),cum_point_cloud(3,:),'k.');
        plot3(vertex(1,:),vertex(2,:),vertex(3,:),'b.');
        view(0,90);
        title('before')
        hold off
        % plot the transformed data 
        figure
        hold on 
        plot3(cum_point_cloud(1,:),cum_point_cloud(2,:),cum_point_cloud(3,:),'k.');
        plot3(vertex_icp(1,:),vertex_icp(2,:),vertex_icp(3,:),'r.');
        view(0,90);
        title('after')
        hold off
        
        % cumulates the transformed data onto the point cloud
        cum_point_cloud = [cum_point_cloud vertex_icp];
    else
        % CPD
        Transform = cpd_register(cum_point_cloud', vertex');
        % Initial point-sets
        figure, cpd_plot_iter(cum_point_cloud', vertex'); title('Before CPD');
        % Registered point-sets
        figure, cpd_plot_iter(cum_point_cloud', Transform.Y);  title('After CPD');
        
        % cumulates the transformed data onto the point cloud
        cum_point_cloud = [cum_point_cloud Transform.Y'];
    end
end

% plot the final cumulated point cloud
figure
hold on 
plot3(cum_point_cloud(1,:),cum_point_cloud(2,:),cum_point_cloud(3,:),'k.');
view(0,90);
title('cumulated point cloud')
hold off

% triangulate and visualize the final surface 
faces = delaunay(cum_point_cloud(1,:),cum_point_cloud(2,:));
figure('Name', ['cumulated mesh surface' num2str(i)])
plot_mesh(cum_point_cloud,faces);
