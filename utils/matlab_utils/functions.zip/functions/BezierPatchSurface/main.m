clc, close all, clear all

load('teapot'); %loading matrix S
% % Matrix S stores all the control points of all the patches of
% % teapot surface such that
% % S(:,:,:,k) control points of kth patch, where k=1..32
% % Size of S(:,:,:,k) is 4 x 4 x 3, i.e., 16 control points and each
% % control point has three values (x,y,z)

% % S(:,:,1,k): x-coordinates of control points of kth patch as 4 x 4 matrix 
% % S(:,:,2,k): y-coordinates of control points of kth patch as 4 x 4 matrix 
% % S(:,:,3,k): z-coordinates of control points of kth patch as 4 x 4 matrix
% % ------------------------------------
[r c d np]=size(S);
% % np: number of patches
ni=20; %number of interpolated values between end control points
u=linspace(0,1,ni); v=u;  %uniform parameterization
% % Higher the value of ni smoother the surface but computationally
% % expensive
% % ------------------------------------
% % Cubic Bezier interpolation of control points of each patch
for k=1:np
    Q(:,:,:,k)=bezierpatchinterp(S(:,:,:,k),u,v); %interpolation of kth patch
end
% % ------------------------------------
% % Plotting a single Bezier Patch in many ways
k=13; %plotting kth patch
plotbezierpatch3D(S(:,:,:,k),Q(:,:,:,k))

% % Plotting Bezier surface (all the patches) in many ways
plotbeziersurface3D(S,Q)

