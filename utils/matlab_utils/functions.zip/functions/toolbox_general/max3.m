function x = max3(x,v)

% max3 - synonymouse with max

x = max(x,v);
