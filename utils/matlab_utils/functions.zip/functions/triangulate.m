clear all
close all

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% planar point set triangulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generate a set of random points in 2D
n = 200; 
vertex = 2*rand(2,n)-1; 
% computes the Delaunay triangulation of the points
faces = delaunay(vertex(1,:),vertex(2,:))'; 

% display of the resulting triangulation
clf; 
subplot(1,2,1); 
hh = plot(vertex(1,:),vertex(2,:), 'k.'); 
axis('equal'); axis('off'); 
set(hh,'MarkerSize',10); 
title('Points'); 
subplot(1,2,2); 
plot_mesh(vertex,faces); 
shading('faceted');
lighting('phong'); 
axis('tight'); 
title('Triangulation'); 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% triangulation of a 3D set of points
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = gallery('uniformdata',[30 1],0);
y = gallery('uniformdata',[30 1],1);
z = gallery('uniformdata',[30 1],2);
dt = delaunayTriangulation(x,y,z);

% display the points 
figure
h = plot3(x,y,z, 'k.'); 
axis('equal'); 
set(h,'MarkerSize',10); 

% plot the triangulation 
figure
tetramesh(dt,'FaceAlpha',0.3); % triangolazione volumetrica

% compute and plot the convex hull of the triangulation
figure
[k,v] = convexHull(dt); % per avere la triangolazione come superficie nel 3d ( prendo solo i punti che stanno sul convex hull)
trisurf(k,dt.Points(:,1),dt.Points(:,2),dt.Points(:,3))
