% compute two control meshes 
[vertex0,face0] = compute_base_mesh('oct'); 
[vertex1,face1] = compute_base_mesh('ico'); 

% plot the control meshes
clf; subplot(1,2,1); 
plot_mesh(vertex0,face0); 
shading('faceted'); 
lighting('flat'); 
view(3); % default 3D view
axis('tight'); 
subplot(1,2,2); 
plot_mesh(vertex1,face1); 
shading('faceted'); 
lighting('flat'); 
view(3); 
axis('tight'); 

input('Press enter to continue...')

% initialize the subdivision of mesh1 
face = face1; 
vertex = vertex1; 
edge = compute_edges(face); 
n = size(vertex,2); 
ne = size(edge,2); 

% Compute the id of the three edges associated to each face 
% v12, v23 and v31 contain the indices of the edges for each face
A = sparse([edge(1,:);edge(2,:)], [edge(2,:);edge(1,:)],...
		[n+(1:ne);n+(1:ne)], n, n); 
v12 = full( A(face(1,:) + (face(2,:)-1)*n) ); 
v23 = full( A(face(2,:) + (face(3,:)-1)*n) ); 
v31 = full( A(face(3,:) + (face(1,:)-1)*n) ); 

% Compute the new faces, each old face generates 4 faces 
face = [ cat(1,face(1,:),v12,v31), cat(1,face(2,:),v23,v12),...
    cat(1,face(3,:),v31,v23), cat(1,v12,v23,v31) ]; 
% Add new vertices at the edges center 
vertex = [vertex, (vertex(:,edge(1,:)) + vertex(:,edge(2,:)))/2 ]; 

% project the points on the sphere
d = sqrt( sum(vertex.^2,1) ); 
vertex = vertex ./ repmat( d, [size(vertex,1) 1]); 

% display before and after subdivision
clf; subplot(1,2,1); 
plot_mesh(vertex1,face1); 
shading('faceted'); 
lighting('flat'); 
view(3); 
axis('tight'); 
subplot(1,2,2); 
plot_mesh(vertex,face); 
shading('faceted'); 
lighting('flat'); 
view(3); 
axis('tight'); 
