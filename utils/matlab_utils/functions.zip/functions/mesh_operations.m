close all
clear all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mesh load and display
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load the mesh
name = 'elephant-50kv.off'; 
options.name = name; % useful for displaying
[vertex,face] = read_mesh(name); 

% plot the mesh
clf; % clear the figure
plot_mesh(vertex, face); 
shading('interp'); % visualizzazione interpolata

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot the mesh with different zoom levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clf; % clear the figure
for i = 1:4 
	subplot(2,2,i); 
	plot_mesh(vertex, face); 
    shading('faceted'); % visualize edges of the mesh
    zoom(1.8^(i+1)); 
end 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% color the vertices of the mesh with a color that 
% depends on the x-coordinate
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options.face_vertex_color = vertex(1,:)';
clf; 
plot_mesh(vertex, face, options);
shading('interp'); 
colormap(jet(256)); 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% display the function cos(50*y) on the mesh
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
options.face_vertex_color = cos(50*vertex(2,:)');
clf; 
plot_mesh(vertex, face, options); 
shading('interp'); 
colormap(jet(256)); 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add noise to the mesh
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clear the color
options.face_vertex_color = [];

% create a matrix of noise with the same size of vertex
noise = randn(size(vertex))*.01;
% set the noise to 0 for the vertex with 
% X coordinate > the average X coordinate
noise(:,vertex(1,:)>mean(vertex(1,:))) = 0; 
% change the vertex position
vertex1 = vertex + noise; 
clf; 
subplot(1,2,1); 
plot_mesh(vertex,face,options); 
axis('tight'); 
subplot(1,2,2); 
plot_mesh(vertex1,face,options);
axis('tight'); 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% warping of the mesh
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vertex1 = sign(vertex) .* (abs(vertex)/max(abs(vertex(:)))).^1.8;
clf; 
subplot(1,2,1); 
plot_mesh(vertex,face,options); 
axis('tight'); 
subplot(1,2,2); 
plot_mesh(vertex1,face,options); 
axis('tight'); 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute and display vertex normals 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load a mesh
name = 'mushroom'; 
options.name = name; 
[vertex,face] = read_mesh(name);
% compute surface normals
[normal,normalf] = compute_normal(vertex,face);
% display the mesh and the vertex normals
clf; 
options.normal = normal; 
plot_mesh(vertex,face,options); 
axis('tight'); 
options.normal = []; 

input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% display vertex and face normals 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we also display the face normals on the previous figure
% hold on
% options.normal = normalf'; 
% plot_mesh(vertex,face,options); 
% shading('faceted'); 
% options.normal = []; 
% 
% input('Press enter to continue...')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mesh extrusion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load a mesh
clear all
name = 'elephant-50kv.off'; 
options.name = name; 
[vertex,face] = read_mesh(name); 
% mesh extrusion along normal direction 
[normal,normalf] = compute_normal(vertex,face);
% extrude each vertex along the normal direction
vertex1 = vertex + .02*normal; 
vertex2 = vertex + .04*normal; 
% no color for display 
options.face_vertex_color = []; 
clf; 
subplot(1,2,1); 
plot_mesh(vertex1,face,options); 
%shading('interp'); 
axis('tight'); 
subplot(1,2,2); 
plot_mesh(vertex2,face,options); 
%shading('interp'); 
axis('tight'); 
